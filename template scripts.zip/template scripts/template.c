/*
 Program: template.c. Describes how a source file is defined.
 Created on: 24 Jan 2020
 Edited on: 24 Jan 2020
 Created by: Yourself
*/

// include your header file.
#include "template.h"

//---------- Contains function definition defined in your header file ------------
void firstFunction()
{
    // Define your first function in here
    // Do something
}

int secondFunction(int param1, int param2)
{
    // Define your second function in here
    // Do another thing here with param1 and param2
}